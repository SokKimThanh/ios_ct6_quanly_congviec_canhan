//
//  CategoryScreenViewModel.swift
//  Project WM
//
//  Created by  User on 15.05.2024.
//

import Foundation
class CategoryScreenViewModel {
    private var categoryArray = [CategoryModel]()
    
    func connectDatabase () {
        _ = SQLiteDatabase.sharedInstance
    }
    func loadDataFromSQLiteDatabase () {
        categoryArray = SQLiteCommands.presentRowsCategory() ?? []
    }
    func numberOfRowsInSection(section: Int) -> Int {
        if categoryArray.count != 0 {
            return categoryArray.count
        }
        return 0
    }
    func cellForRowAt(indexPath: IndexPath) -> CategoryModel{
        return categoryArray[indexPath.row]
    
    }
}
