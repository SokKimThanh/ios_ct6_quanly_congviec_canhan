//
//  ListTaskTableViewController.swift
//  Project WM
//
//  Created by  User on 11.05.2024.
//

import UIKit
// buoc 1: Tao view controller danh sach cong viec
class ListTaskTableViewController:
    /* tuan thu cac giao thuc */UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    private var viewModel = TaskScreenViewModel()
    // ket noi table task view
    @IBOutlet weak var tableTasksView: UITableView!
    // ket noi button add task
    @IBOutlet weak var btnAddTask: UIButton!
    
    // buoc 2: tai du lieu
    override func viewDidLoad() {
        super.viewDidLoad()
       
        title = "Your Task"
        btnAddTask.layer.cornerRadius = btnAddTask.frame.size.width / 2
        btnAddTask.clipsToBounds = true
        // Connect to database
        viewModel.connectDatabase()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        loadData()
        tableTasksView.reloadData()
    }
    // MARK: - Table view data source
    // Buoc 3: Tao Nguon du lieu
    private func loadData(){
        viewModel.loadDataFromSQLiteDatabase()
    }
    // tra ve so hang trong table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection(section: section)
    
    }
    // tra ve cell co the tuy chinh trong table
    // xử lý dealine trong table view controller và truyền thời gian cần theo dõi cho cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // lay cell tuy chinh
        // neu khong co cell thi tao moi
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        // Configure the cell...
        // lay du lieu viewModel tai vi tri duoc chon indexpath
        // cau hinh giao dien cua cell voi du lieu tu task model
        let taskModel = viewModel.cellForRowAt(indexPath: indexPath)
        
        if let taskCell = cell as? TaskCellTableViewCell {
            taskCell.setCellWithValuesOf(taskModel)
        }
        
        // Lên lịch thông báo cho công việc
        scheduleLocalNotification(for: taskModel)
        
        
        return cell
    }
    //Lên Lịch Thông Báo Tự Động:
    func scheduleLocalNotification(for task: TaskModel) {
        let content = UNMutableNotificationContent()
        content.title = "Công việc cần hoàn thành"
        content.body = task.content
        // Tạo trigger dựa trên thời gian của công việc
        let trigger = UNCalendarNotificationTrigger(dateMatching: task.date, repeats: true)

        // Tạo request thông báo
        let request = UNNotificationRequest(identifier: task.id, content: content, trigger: trigger)

        // Thêm request vào UNUserNotificationCenter
        UNUserNotificationCenter.current().add(request) { (error) in
            if let error = error {
                print("Lỗi khi thêm thông báo: \(error.localizedDescription)")
            } else {
                print("Thông báo đã được lên lịch cho công việc: \(task.taskDescription)")
            }
        }
    }

    // Buoc 4: Xac nhan xoa
    // hien thi thong bao xac nhan xoa cong viec
     func showDeleteConfirmationAlert(for indexPath: IndexPath) {
           let alertController = UIAlertController(title: "Confirm Delete", message: "Are you sure you want to delete this task?", preferredStyle: .alert)
           
           let deleteAction = UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in
               self?.deleteTask(at: indexPath)
           }
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           
           alertController.addAction(deleteAction)
           alertController.addAction(cancelAction)
           
           present(alertController, animated: true, completion: nil)
        }
    // xoa cong viec trong database
    func deleteTask(at indexPath: IndexPath) {
           let task = viewModel.cellForRowAt(indexPath: indexPath)
           SQLiteCommands.deleteRow(taskId: task.id)
           // Cập nhật giao diện sau khi xóa
           loadData()
           tableTasksView.reloadData()
       }
    // Delte row task
    // xoa cong viec trong table view
       func tableView(_ tableView: UITableView, commit editingStyle:UITableViewCell.EditingStyle,forRowAt indexPath: IndexPath){
          if editingStyle == .delete {
//              let task = viewModel.cellForRowAt(indexPath: indexPath)
//              SQLiteCommands.deleteRow(taskId: task.id)
//              // update giao dien sao khi xoa
//              self.loadData()
//              self.tableTasksView.reloadData()
              showDeleteConfirmationAlert(for: indexPath)
          }
      }
     
    // MARK: - Navigation
    // dieu huong de trang add task view controller
    // Passes selected contact from table cell to AddTaskViewCOntroller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          if segue.identifier == "editTask" {
              guard let newTaskViewController = segue.destination as? AddTaskViewController else {
                  return
              }
              guard let selectedTaskCell = sender as? TaskCellTableViewCell else {return}
              if let indexPath = tableTasksView.indexPath(for: selectedTaskCell) {
                 let selectedTask = viewModel.cellForRowAt(indexPath: indexPath)
                  newTaskViewController.viewModel = NewTaskViewModel(taskValue: selectedTask)
              }

          }
      }
    //        let reuse = "cell"
    //        if let cell = tableView.dequeueReusableCell(withIdentifier: reuse, for: indexPath) as? TaskCellTableViewCell {
    //            cell.lblContent.text = arrTask[indexPath.row].content
    //            cell.lblDate.text = arrTask[indexPath.row].date
    //            return cell
    //        }
    //        fatalError("khong return duoc")

    
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return viewModel.numberOfRowsInSection(section: section)
//    }
//
//
//
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
//
//        // Configure the cell...
//        let object = viewModel.cellForRowAt(indexPath: indexPath)
//        if let taskCell = cell as? TaskCellTableViewCell {
//            taskCell.setCellWithValuesOf(object)
//        }
//        return cell
//    }
//
//
}
