//
//  CategoryModel.swift
//  Project WM
//
//  Created by  User on 15.05.2024.
//

import Foundation
struct CategoryModel {
    let categoryId : Int
    let nameCate : String
   
}
