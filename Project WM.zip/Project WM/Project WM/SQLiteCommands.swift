//
//  SQLiteCommands.swift
//  Project WM
//
//  Created by  User on 11.05.2024.
//

import Foundation
import SQLite
class SQLiteCommands {
    static var table = Table("task")
    static var tableUsers = Table("users")
    static var tableCategory = Table("category")
    //Expressions task
    static let id = Expression<Int>("id")
    static let content = Expression<String>("content")
    static let date = Expression<String>("date")
    //Expressions users
    static let userId = Expression<Int>("id")
    static let username = Expression<String>("username")
    static let password = Expression<String>("password")
    //Expressions category
    static let caterogyId = Expression<Int>("caterogyId")
    static let nameCate = Expression<String>("nameCate")
   
    // Creating table
    static func createTable (){
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Database connect error")
            return
        }
        do {
            // Create table Taks
            try database.run(table.create(ifNotExists: true)  {  table in
                table.column(id, primaryKey: true)
                table.column(content)
                table.column(date)
            })
           
        }
        catch{
            print("Table already exists \(error)")
        }
    }
    // Creating user table
       static func createUserTable() {
           guard let database = SQLiteDatabase.sharedInstance.database else {
               print("Database connect error")
               return
           }
           do {
               try database.run(tableUsers.create(ifNotExists: true) { table in
                   table.column(userId, primaryKey: true)
                   table.column(username, unique: true)
                   table.column(password)
               })
           } catch {
               print("Table already exists \(error)")
           }
       }
    // Creating user Category
       static func createCatergoryTable() {
           guard let database = SQLiteDatabase.sharedInstance.database else {
               print("Database connect error")
               return
           }
           do {
               try database.run(tableCategory.create(ifNotExists: true) { table in
                   table.column(caterogyId, primaryKey: true)
                   table.column(nameCate)
                  
               })
           } catch {
               print("Table already exists \(error)")
           }
       }
    
    static func insertUser(username: String, password: String) -> Bool {
           guard let database = SQLiteDatabase.sharedInstance.database else {
               print("Datastore connection error")
               return false
           }
           do {
               try database.run(tableUsers.insert(self.username <- username, self.password <- password))
               return true
           } catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT {
               print("Insert user failed: \(message), in \(String(describing: statement))")
               return false
           } catch let error {
               print("Insert user failed: \(error)")
               return false
           }
       }
    static func verifyUser(username: String, password: String) -> Bool {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return false
        }
        do {
            let query = tableUsers.filter(self.username == username && self.password == password)
            let user = try database.pluck(query)
            return user != nil
        } catch {
            print("User verification failed: \(error)")
            return false
        }
    }
    // Insert Category
    static func insertCategory(_ categoryValues: CategoryModel)->Bool? {
        guard let databae = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error ")
            return nil
        }
        do {
            try databae.run(tableCategory.insert(nameCate <- categoryValues.nameCate))
            return true
        }
        catch let Result.error(message , code , statement) where code == SQLITE_CONSTRAINT{
            print("Insert row failed : \(message) , in \(String(describing: statement))")
            return false
            
        }
        catch let error {
            print("Insert faield : \(error)")
            return false
        }
    }
   
    static func insertTask(_ taskValues:TaskModel)->Bool? {
        guard let databae = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error ")
            return nil
        }
        do {
            try databae.run(table.insert(content <- taskValues.content, date <- taskValues.date))
            return true
        }
        catch let Result.error(message , code , statement) where code == SQLITE_CONSTRAINT{
            print("Insert row failed : \(message) , in \(String(describing: statement))")
            return false
            
        }
        catch let error {
            print("Insert faield : \(error)")
            return false
        }
    }
    // Update Category
    static func updateCategory (_ categoryValues: CategoryModel) -> Bool? {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return nil
        }
        //Extracts
        let category = table.filter(caterogyId == categoryValues.categoryId).limit(1)
        do {
            if try database.run(category.update(nameCate <- categoryValues.nameCate)) > 0 {
                print("Update Category Suceess")
                return true
            }
            else {
                print("Could not update Category")
                return false
            }
        }
        catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT{
            print("Update row faild \(message) ,in \(String(describing: statement))")
            return false
            
        }
        catch let error {
            print("update Faild \(error)")
            return false
        }
    }
    // Update Task
    static func updateTask (_ taskValues: TaskModel) -> Bool? {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return nil
        }
        //Extracts
        let task = table.filter(id == taskValues.id).limit(1)
        do {
            if try database.run(task.update(content <- taskValues.content,date <- taskValues.date)) > 0 {
                print("Update Task Suceess")
                return true
            }
            else {
                print("Could not update Task")
                return false
            }
        }
        catch let Result.error(message, code, statement) where code == SQLITE_CONSTRAINT{
            print("Update row faild \(message) ,in \(String(describing: statement))")
            return false
            
        }
        catch let error {
            print("update Faild \(error)")
            return false
        }
    }
    // Present Rows
    static func presentRowsCategory() -> [CategoryModel]? {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return nil
        }
        var categoryArray = [CategoryModel]()
        
        tableCategory = tableCategory.order(caterogyId.desc)
        do {
            for category in try database.prepare(tableCategory){
                let idValue = category[caterogyId]
                let nameCategoryValue = category[nameCate]

                // Creating objectc
                let cateObject = CategoryModel(categoryId: idValue, nameCate: nameCategoryValue)
                // Add object to an array
                categoryArray.append(cateObject)
                print("id :\(category[caterogyId]) , name  : \(category[nameCate])")
            }
        } catch {
            print("Present row error \(error)")
        }
        return categoryArray
    }
    // Present Rows
    static func presentRowsTask() -> [TaskModel]? {
        guard let database = SQLiteDatabase.sharedInstance.database else {
            print("Datastore connection error")
            return nil
        }
        var taskArray = [TaskModel]()
        
        table = table.order(id.desc)
        do {
            for task in try database.prepare(table){
                let idValue = task[id]
                let contentValue = task[content]
                let dateValue = task[date]
                
                // Creating objectc
                let taskObject = TaskModel(id: idValue, content: contentValue, date: dateValue)
                // Add object to an array
                taskArray.append(taskObject)
                print("id \(task[id]) , content : \(task[content]) , date : \(task[date])")
            }
        } catch {
            print("Present row error \(error)")
        }
        return taskArray
    }
    // Delete Row
    static func deleteRow(taskId: Int) {
        guard let database = SQLiteDatabase.sharedInstance.database else{
            print("Datastore connection error")
            return
        }
        do {
            let task = table.filter(id == taskId).limit(1)
            try database.run(task.delete())
        }
        catch {
            print("Delete Row fail \(error)")
        }
    }
    // Delete Row Category
    static func deleteRowCategory(cateId: Int) {
        guard let database = SQLiteDatabase.sharedInstance.database else{
            print("Datastore connection error")
            return
        }
        do {
            let category = table.filter(cateId == caterogyId).limit(1)
            try database.run(category.delete())
        }
        catch {
            print("Delete Row fail \(error)")
        }
    }
}
