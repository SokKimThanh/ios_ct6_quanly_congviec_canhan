//
//  CategoryCellTableViewCell.swift
//  Project WM
//
//  Created by  User on 15.05.2024.
//

import UIKit

class CategoryCellTableViewCell: UITableViewCell {

   
    
    @IBOutlet weak var lblNameCategory: UILabel!
    // set up task values
    func setCellWithValuesOf(_ category: CategoryModel){
        lblNameCategory.text = category.nameCate
        
    }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }

}
