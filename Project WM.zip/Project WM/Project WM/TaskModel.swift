//
//  TaskModel.swift
//  Project WM
//
//  Created by  User on 10.05.2024.
//

import Foundation
struct TaskModel {
    let id : Int
    let content : String
    let date : String
    
}
