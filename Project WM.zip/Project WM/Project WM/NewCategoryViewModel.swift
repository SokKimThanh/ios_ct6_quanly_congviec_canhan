//
//  NewCategoryViewModel.swift
//  Project WM
//
//  Created by  User on 15.05.2024.
//

import UIKit
class NewCategoryViewModel {
    private var categoryValue: CategoryModel?
    let categoryId: Int?
    let nameCate: String?
   
    init(categoryValue: CategoryModel?) {
        self.categoryValue = categoryValue
      
        self.categoryId = categoryValue?.categoryId
        self.nameCate = categoryValue?.nameCate
       
    }
}
