//
//  UserModel.swift
//  Project WM
//
//  Created by  User on 14.05.2024.
//

import Foundation
struct UserModel {
    let id: Int
    let username: String
    let password: String 
}
