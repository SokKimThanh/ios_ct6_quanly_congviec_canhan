//
//  NewTaskViewController.swift
//  Project WM
//
//  Created by  User on 11.05.2024.
//

import UIKit


class NewTaskViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
