//
//  ListCategoryTableViewController.swift
//  Project WM
//
//  Created by  User on 15.05.2024.
//

import UIKit

class ListCategoryTableViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
        {
    @IBOutlet weak var tableCategoryCell: UITableView!

    private var viewModel = CategoryScreenViewModel()

    @IBOutlet weak var btnAddCategory: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Thiet nut hinh tron
        btnAddCategory.layer.cornerRadius = btnAddCategory.frame.size.width / 2
          //  viewModel.connectDatabase()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        loadData()
        tableCategoryCell.reloadData()
       
    }
  
    // MARK: - Table view data source

    private func loadData(){
        viewModel.loadDataFromSQLiteDatabase()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection(section: section)
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellCate", for: indexPath)
       
               // Configure the cell...
               let object = viewModel.cellForRowAt(indexPath: indexPath)
               if let taskCell = cell as? CategoryCellTableViewCell {
                   taskCell.setCellWithValuesOf(object)
               }
               return cell
        

    }
     func showDeleteConfirmationAlert(for indexPath: IndexPath) {
           let alertController = UIAlertController(title: "Confirm Delete", message: "Are you sure you want to delete this category?", preferredStyle: .alert)
           
           let deleteAction = UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in
               self?.deleteCategory(at: indexPath)
           }
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           
           alertController.addAction(deleteAction)
           alertController.addAction(cancelAction)
           
           present(alertController, animated: true, completion: nil)
        }
    func deleteCategory(at indexPath: IndexPath) {
           let category = viewModel.cellForRowAt(indexPath: indexPath)
        SQLiteCommands.deleteRowCategory(cateId: category.categoryId)
           // Cập nhật giao diện sau khi xóa
           loadData()
           tableCategoryCell.reloadData()
       }
    // Delte row Category
       func tableView(_ tableView: UITableView, commit editingStyle:UITableViewCell.EditingStyle,forRowAt indexPath: IndexPath){
          if editingStyle == .delete {
//              let task = viewModel.cellForRowAt(indexPath: indexPath)
//              SQLiteCommands.deleteRow(taskId: task.id)
//              // update giao dien sao khi xoa
//              self.loadData()
//              self.tableTasksView.reloadData()
              showDeleteConfirmationAlert(for: indexPath)
          }
      }
     
      // MARK: - Navigation
  //
  //    // Passes selected contact from table cell to AddTaskViewCOntroller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          if segue.identifier == "editCategory" {
              guard let newCategoryViewController = segue.destination as? AddCategoryViewController else {
                  return
              }
              guard let selectedCategoryCell = sender as? CategoryCellTableViewCell else {return}
              if let indexPath = tableCategoryCell.indexPath(for: selectedCategoryCell) {
                 let selectedCategory = viewModel.cellForRowAt(indexPath: indexPath)
                  newCategoryViewController.viewModel = NewCategoryViewModel(categoryValue: selectedCategory)
              }

          }
      }
  
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
