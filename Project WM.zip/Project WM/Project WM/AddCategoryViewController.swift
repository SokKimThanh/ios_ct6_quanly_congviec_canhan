//
//  AddCategoryViewController.swift
//  Project WM
//
//  Created by  User on 15.05.2024.
//

import UIKit

class AddCategoryViewController: UIViewController,UITextFieldDelegate {

  
    @IBOutlet weak var textFieldNameCategory: UITextField!
    
    
    @IBOutlet weak var btnAddCategory: UIButton!
    var viewModel: NewCategoryViewModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        createTableCategory()
        setUpViews()
        textFieldNameCategory.layer.borderColor = UIColor.green.cgColor
       
        btnAddCategory.layer.cornerRadius = btnAddCategory.frame.size.width / 2
        btnAddCategory.clipsToBounds  = true
        textFieldNameCategory.delegate = self
        
    }
    // MARK: Connect to datase and create table
    private func createTableCategory(){
        SQLiteCommands.createCatergoryTable()
       
    }
    private func setUpViews() {
        if let viewModel = viewModel {
            textFieldNameCategory.text = viewModel.nameCate
        }
    }
   
    @IBAction func btnAddCategory(_ sender: UIButton) {
        let cateId: Int = viewModel == nil ? 0 : viewModel.categoryId!
        let nameCate = textFieldNameCategory.text ?? ""
      
        let categoryValues = CategoryModel(categoryId: cateId, nameCate: nameCate)
        if viewModel == nil {
            createNewCategory(categoryValues)
            
        }else {
            updateCategory(categoryValues)
        }
    }
    // MARK: Update Task
    private func updateCategory(_ categoryValues: CategoryModel) {
        let categoryUpdatedInTable = SQLiteCommands.updateCategory(categoryValues)
        // Phone number number is unique to each task so we check if it alreadly exists
        if categoryUpdatedInTable == true {
            if let cellClicked = navigationController {
                cellClicked.popViewController(animated: true)
            }
            else {
                showError("Error", message: "This category cannot be updated")
            }
        }
    }
    private func createNewCategory(_ categoryValues: CategoryModel){
        let categoryAddedToTable = SQLiteCommands.insertCategory(categoryValues)
        if categoryAddedToTable == true {
            if let cellClicked = navigationController {
                cellClicked.popViewController(animated: true)
            }
        }
        else {
            showError("Error", message: "Nhap Lai Du Lieu ")
        }
    }
    
    
    @IBAction func btnCancel(_ sender: UIBarButtonItem) {
        if let cellClicked = navigationController {
            cellClicked.popViewController(animated: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
